# Digital Bhaiya Sniper Bot
A Telegram bot for scalping support.